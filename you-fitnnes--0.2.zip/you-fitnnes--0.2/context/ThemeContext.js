import { CreateContext }  from 'react'

const ThemeContext =  CreateContext (["light", () => {}]);

export default ThemeContext;
