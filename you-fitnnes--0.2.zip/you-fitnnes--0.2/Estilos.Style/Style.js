import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    marginHorizontal: 16,
    backgroundColor: '#f6f7f9 ',
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 50,
  },

  title: {
    textAlign: 'center',
    marginVertical: 8,
  },

  fixToText: {
    margin: 20,
    borderWidth: 1,
    borderRadius: 7,
    fontSize: 20,
    borderColor: 'black',
    justifyContent: 'center',
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },

  containerLogo: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  btnSubmit: {
    backgroundColor: '#35AAFF',
    width: '90%',
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 7,
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff',
  },
  resultado: {
    alignSelf: 'center',
    color: 'black',
    fontSize: 45,
    fontWeight: 'bold',
    padding: 6,
  },
  entrada: {
    flexDirection: 'row',
  },
  sub_input: {
    backgroundColor: '#FF8C00',
    width: '90%',
    marginBottom: 15,
    color: '#222',
    fontSize: 17,
    borderRadius: 70,
    padding: 7,
  },

  input: {
    backgroundColor: '#000000',
    flexDirection: 'center',
    margin: 20,
    borderWidth: 1,
    borderRadius: 7,
    fontSize: 20,
    borderColor: 'black',
    width: 300,
  },

  text: {
    margin: 20,
    marginTop: 10,
    padding: 10,
    width: 300,
    backgroundColor: '#111111',
    fontSize: 16,
    fontWeight: 'bold',
    borderRadius: 7,
  },
  botao: {
    margin: 10,
    borderWidth: 1,
    borderRadius: 7,
    fontSize: 20,
    borderColor: 'orange',
    width: 300,
  },
  botaoentrar: {
    margin: 20,
    borderWidth: 1,
    borderRadius: 7,
    fontSize: 20,
    borderColor: 'black',
    width: 300,
  },

  botaobuscar: {
    margin: 10,
    marginTop: 5,
    borderWidth: 1,
    borderRadius: 7,
    fontSize: 20,
    width: 300,
    borderColor: 'black',
    justifyContent: 'center',
  },

  logo: {
    width: 150,
    height: 150,
    alignItems: 'center',
  },
  textinputlogin: {
    margin: 10,
    marginTop: 10,
    padding: 10,
    width: 300,
    backgroundColor: '#FF8C00',
    fontSize: 20,
    fontWeight: 'bold',
    borderRadius: 7,
    alignItems: 'center',
  },
  textinput: {
    justifyContent: 'center',
    margin: 20,
    marginTop: 10,
    padding: 10,
    width: 300,
    backgroundColor: '#00000',
    fontSize: 16,
    fontWeight: 'bold',
    borderRadius: 7,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
  },
});
