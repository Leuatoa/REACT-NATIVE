import React, { Component } from 'react';
 import {       
  Button,
  Alert,  
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  
} from 'react-native';

import { createAppContainer } from 'react-navigation';
import { createStackNavigator, createDrawerNavigator,  } from 'react-navigation-stack';

import {
  HomeScreen, 
  LoginALunoScreen,
  LoginPersonalScreen,
  ProfileAlunoScreen,
  ProfilePersonalScreen,
  FichaTreinoScreen,
  BuscarALunosScreen, 
  ExerciciosScreen,
  AvaliacaoFisicaScreen,
  SolicitarTreinoScreen,
  GifsScreen,
} from './screens';


const AppNavigator = createStackNavigator (
  {
    Home: {
      screen: HomeScreen,
    },
    ProfileALuno: {
      screen: ProfileAlunoScreen,
    },
    ProfilePersonal: {
      screen: ProfilePersonalScreen,
    },
    LoginAluno: {
      screen: LoginALunoScreen,
    },
    LoginPersonal: {
      screen: LoginPersonalScreen,
    },
    Exercicios: {
      screen: ExerciciosScreen,
    },
    FichaTreino: {
      screen: FichaTreinoScreen,
    },
    BuscarALunos: {
      screen: BuscarALunosScreen,
    },
    AvaliacaoFisica: {
      screen: AvaliacaoFisicaScreen,
    },

    SolicitarTreino: {
      screen: SolicitarTreinoScreen,
    },
    Gifs: {
      screen: GifsScreen,
    },
  },

  {
    initialRouteName: '',
  }
);

const AppContainer = createAppContainer(AppNavigator);

const styles = StyleSheet.create({});
  
export default class App extends Component {
  render() {
    return <AppContainer />;
  }
}