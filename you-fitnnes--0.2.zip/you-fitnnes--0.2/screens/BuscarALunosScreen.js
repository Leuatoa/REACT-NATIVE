import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import Style from '../Estilos.Style/Style';
import ListaALunos from '../components/ListaAlunos';

export default class BuscarALunosScreen extends Component {
  static navigationOptions = {
    title: 'ALUNOS',
    headerStyle: {
      backgroundColor: '#000000',
    },
    headerTintColor: '#ffff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  render() {
    return (
      <View style={Style.container}>
        <ScrollView>
          <View>
            <TextInput style={Style.textinput} />
          </View>

          <View style={Style.botaobuscar}>
            <Button title="BUSCAR" color="#000000" />
          </View>
          <View>
            <ListaALunos />
          </View>
        </ScrollView>
      </View>
    );
  }
}
