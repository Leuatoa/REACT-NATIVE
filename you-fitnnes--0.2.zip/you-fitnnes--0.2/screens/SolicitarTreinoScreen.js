import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
} from 'react-native';

import Style from '../Estilos.Style/Style';

function Separator() {
  return <View style={Style.separator} />;
}

export default class SolicitarTreinoScreen extends Component {
  static navigationOptions = {
    title: 'SOLICITAR NOVO TREINO',
    headerStyle: {
      backgroundColor: '#000000',
    },
    headerTintColor: '#ffff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  render() {
    return (
       <View style={Style.background}>
      <View style={Style.container}>
        <SafeAreaView
           style={Style.container}> 
          <View>
            <Text style={Style.title} />
            <Button
              title="Olá! Peço que aqui você descreva os motivos pelo qual você está solicitando este treino! Obrigado."
              color="#FF8C00"
            />
          </View>
          <Separator />

          <View>
            <TextInput
            onChangeText={() => {}}
              style={Style.textinput} 
            />
          </View>

          <View>
            <Text style={Style.title} />
            <View
              style={Style.botaoentrar}>
              <Button
                title="ENVIAR"
                color="#000000"
                onPress={() => Alert.alert('SOLICITAÇÃO ENVIADA COM SUCESSO!')}
              />
            </View>
          </View>
        </SafeAreaView>
      </View>
      </View>
    );
  }
}
