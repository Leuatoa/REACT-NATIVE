import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  Card,
} from 'react-native';

import Style from '../Estilos.Style/Style';

export default class LoginPersonalScreen extends Component {
  state = {
    matricula: '',
    password: '',
  };
  
  login = async () => {
    const { matricula, password } = this.state;

  }

  render() {
    return (
      <View style={Style.background}>
        <View style={Style.container}>
          <Image style={Style.logo} source={require('../assets/logo.png')} />

          <View style={Style.textinputlogin}>
            <TextInput
              placeholder="Digite sua matricula"
              value={this.state.matricula}
              onChangeText={matricula => this.setState({ matricula })}
            />
          
          </View>

          <View style={Style.textinputlogin}>
            <TextInput
              secureTextEntry={true}
              placeholder="Digite sua senha"
              value={this.state.password}
              onChangeText={password => this.setState({ password })}
          
            />
          </View>

          <View style={Style.botaoentrar}>
            <Button
              title="ENTRAR"
              color="#000000"
              onPress={() =>
                this.props.navigation.navigate('ProfilePersonal', {
                  name: 'JOÃO',
                  age: '22',
                })
              }
            />
          </View>
        </View>
      </View>
    );
  }
}
