import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';

import Style from '../Estilos.Style/Style'

export default class HomeScreen extends Component {
  static navigationOptions;
  render() {
    return (
      <View style={Style.background}>
        <View style={Style.container}>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 40 }}>BEM VINDO!</Text>
          </View>

         <View style={Style.logo}>
            <Image
              style={{ width: 150, height: 150 }}
              source={require('../assets/logo.png')}
            />
          </View>

           <View style={Style.botao}>
            <Button
              title="SOU PERSONAL"
              color="#FF8C00"
              onPress={() => this.props.navigation.navigate('LoginPersonal')}
            />
          </View>

           <View style={Style.botao}>
            <Button
              title="SOU ALUNO"
              color="#FF8C00"
              onPress={() => this.props.navigation.navigate('LoginAluno')}
            />
          </View>
        </View>
      </View>
    );
  }
}
