import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from 'react-native';

import Style from '../Estilos.Style/Style';

function Separator() {
  return <View style={Style.separator} />;
}

export default class GifsScreen extends Component {
  static navigationOptions = {
    title: 'GIFS',
    headerStyle: {
      backgroundColor: '#000000',
    },
    headerTintColor: '#ffff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  render() {
    return (
       <View style={Style.background}>
      <View style={Style.container}>
        <ScrollView>
          <SafeAreaView style={Style.container}>
            <View>
              <Text style={Style.title}>
                Olá, observe o GIF abaixo e execute o movimento da mesma forma.
                Não tente fazer diferente, pois você pode acabar com uma lesão
                grave!
              </Text>
              <View style={Style.botao}>
                <Button title="gif" color="#FF8C00" />
              </View>
            </View>
            <Separator />
            <View>
              <Text style={Style.title}>
                Exrcicío conhecido como Supino Reto,nele é trablhado o músculo
                superior do peito, tanto como os ligamento diretos por ex:
                Manguito e Deltóide superior e lateral. É recomendado que sua
                execução seja feita com uma carga suportavél e também seja feito
                de forma concentrada, sem deixar o peso perder o foco muscular.
              </Text>
            </View>

            <View>
              <Text style={Style.title} />
              <View style={Style.fixToText}>
                <Button
                  color="#000000"
                  title="HELP"
                  onPress={() =>
                    Alert.alert(
                      'Tem alguma dúvida sobre seu treino? Procure o seu personal, e ele vai te auxiliar.Se você acha que seu treino está muito leve ou até mesmo muito pesado para o que você pode suportar, por favor,solicite um novo treino ao seu personal!'
                    )
                  }
                />
              </View>
            </View>
          </SafeAreaView>
        </ScrollView>
      </View>
      </View>
    );
  }
}
