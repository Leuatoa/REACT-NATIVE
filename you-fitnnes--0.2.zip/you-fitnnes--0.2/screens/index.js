import HomeScreen from './HomeScreen';
import LoginALunoScreen from './LoginALunoScreen';
import LoginPersonalScreen from './LoginPersonalScreen';
import ProfileAlunoScreen from './ProfileAlunoScreen';
import ProfilePersonalScreen from './ProfilePersonalScreen';
import FichaTreinoScreen from './FichaTreinoScreen';
import ExerciciosScreen from './ExerciciosScreen';
import BuscarALunosScreen from './BuscarALunosScreen';
import AvaliacaoFisicaScreen from './AvaliacaoFisicaScreen';
import SolicitarTreinoScreen from './SolicitarTreinoScreen';
import GifsScreen from './GifsScreen';

export {
  HomeScreen,
  LoginALunoScreen,
  LoginPersonalScreen,
  ProfileAlunoScreen,
  ProfilePersonalScreen,
  FichaTreinoScreen,
  BuscarALunosScreen,
  ExerciciosScreen,
  AvaliacaoFisicaScreen,
  SolicitarTreinoScreen,
  GifsScreen,
};
