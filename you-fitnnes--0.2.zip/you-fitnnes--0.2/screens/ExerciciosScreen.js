import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from 'react-native';

import Style from '../Estilos.Style/Style';

function Separator() {
  return <View style={Style.separator} />;
}

export default class ExerciciosScreen extends Component {
  static navigationOptions = {
    title: 'EXERCICIOS',
    headerStyle: {
      backgroundColor: '#000000',
    },
    headerTintColor: '#ffff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  render() {
    return (
       <View style={Style.background}>
        <ScrollView>
        <Separator />
          <SafeAreaView style={Style.container}>
            <View>
              <Text style={Style.title}>
                Esta ficha de treino contém exercícios para os musculos
                superiores.
              </Text>
              <View style={Style.botao}>
                <Button
                  title="Superior"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
            </View>

            <Separator />

            <View>
              <Text style={Style.title}>
                Esta ficha de treino contém exercícios para os musculos
                Inferiores.
              </Text>
              <View style={Style.botao}>
                <Button
                  title="Inferior"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
            </View>

            <Separator />

            <View>
              <Text style={Style.title}>
                Esta ficha de treino contém exercícios para os musculos
                Trabalhados a partir da Dorsal.
              </Text>
              <View style={Style.botao}>
                <Button
                  title="Dorsal"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
            </View>
            <Separator />
            <View>
              <Text style={Style.title}>
                Esta ficha de treino contém exercícios para os musculos
                Trabalhados de forma secundária.
              </Text>
              <View style={Style.botao}>
                <Button
                  title="Sub-Treinos"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
            </View>

            <Separator />

            <View>
              <Text style={Style.title} />
              <View style={Style.fixToText}>
                <Button
                  color="#000000"
                  title="HELP"
                  onPress={() =>
                    Alert.alert(
                      'Tem alguma dúvida sobre seu treino? Procure o seu personal, e ele vai te auxiliar.Se você acha que seu treino está muito leve ou até mesmo muito pesado para o que você pode suportar, por favor,solicite um novo treino ao seu personal!'
                    )
                  }
                />
              </View>
            </View>
          </SafeAreaView>
        </ScrollView>
      </View>
     
    );
  }
}
