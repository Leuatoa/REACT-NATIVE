import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
} from 'react-native';

import Style from '../Estilos.Style/Style';

function Separator() {
  return <View style={Style.separator} />;
}

export default class FichaTreinoScreen extends Component {
  static navigationOptions = {
    title: 'FICHA DE TREINO',
    headerStyle: {
      backgroundColor: '#000000',
    },
    headerTintColor: '#ffff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  render() {
    return (
       <View style={Style.background}>
      <View>
        <ScrollView>
          <SafeAreaView style={Style.container}>
            <View >
              <Text style={Style.title}>
                Esta é a sua lista de Exercicios, caso tenha dúvida na excecução
                de algum, basta clickar nele.
              </Text>
              <View style={Style.botao}>
                <Button
                  title="Supino Reto 3x12"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
              <Separator />

              <View style={Style.botao}>
                <Button
                  title="Crucifixo 4x12"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
              <Separator />

              <View style={Style.botao}>
                <Button
                  title="Supino Inclinado 3x12"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
              <Separator />
              <View style={Style.botao}>
                <Button
                  title="Supino Reclinado 3x12"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
              <Separator />

              <View style={Style.botao}>
                <Button
                  title="Tricéps Pulley 4x12"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
              <Separator />

              <View style={Style.botao}>
                <Button
                  title="Tricéps Testa 4x12"
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
              <Separator />

              <View style={Style.botao}>
                <Button
                  title="Esteira 20 Min."
                  color="#FF8C00"
                  onPress={() => this.props.navigation.navigate('Gifs')}
                />
              </View>
              <Separator />

              <View>
                <Text style={Style.title} />
                <View style={Style.fixToText}>
                  <Button
                    title="HELP"
                    color="#000000"
                    onPress={() =>
                      Alert.alert(
                        'Tem alguma dúvida sobre seu treino? Procure o seu personal, e ele vai te auxiliar.Se você acha que seu treino está muito leve ou até mesmo muito pesado para o que você pode suportar, por favor,solicite um novo treino ao seu personal!'
                      )
                    }
                  />
                </View>
              </View>
            </View>
          </SafeAreaView>
        </ScrollView>
      </View>
      </View>
    );
  }
}
