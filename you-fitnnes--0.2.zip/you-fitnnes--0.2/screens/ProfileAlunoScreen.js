import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import Style from '../Estilos.Style/Style';

function Separator() {
  return <View style={Style.separator} />;
}

export default class ProfileAlunoScreen extends Component {
  static navigationOptions = {
    title: 'PERFIL',
    headerStyle: {
      backgroundColor: '#000000',
    },
    headerTintColor: '#ffff',
    headerTitleStyle: {
      fontWeight: 'bold',
      alignItems: 'center',
    },
  };

  render() {
    const name = this.props.navigation.getParam('name', 'Anônimo');
    const age = this.props.navigation.getParam('age', 'nao determinado');

    return (
      <View style={Style.background}>
        <View style={Style.container}>
          <ScrollView>
            <View style={{ margin: 20 }} />

            <View style={{ alignItems: 'center' }}>
              <Image
                style={{ width: 150, height: 150 }}
                source={require('../assets/LOGIS.png')}
              />
              <Text style={{ fontSize: 30 }}> {JSON.stringify(name)} </Text>
            </View>
            <Separator />
            <View style={Style.botao}>
              <Button
                title="EDITAR PERFIL"
                color="#000000"
                style={{ borderRadius: 7 }}
                onPress={() => this.props.navigation.navigate('')}
              />
            </View>

            <Separator />
            <View style={Style.botao}>
              <Button
                title="FICHA DE TREINO"
                color="#FF8C00"
                style={{ borderRadius: 7 }}
                onPress={() => this.props.navigation.navigate('FichaTreino')}
              />
            </View>

            <Separator />

            <View style={Style.botao}>
              <Button
                title="EXERCICIOS"
                color="#FF8C00"
                s
                onPress={() => this.props.navigation.navigate('Exercicios')}
              />
            </View>
            <Separator />
            <View style={Style.botao}>
              <Button
                title="AVALIAÇÃO FISICA"
                color="#FF8C00"
                onPress={() =>
                  this.props.navigation.navigate('AvaliacaoFisica')
                }
              />
            </View>
            <Separator />
            <View style={Style.botao}>
              <Button
                title="SOLICITAR NOVO TREINO"
                color="#FF8C00"
                style={{ borderRadius: 7 }}
                onPress={() =>
                  this.props.navigation.navigate('SolicitarTreino')
                }
              />
            </View>
            <Separator />
            <View style={Style.botao}>
              <Button
                title="SAIR"
                color="#FF8C00"
                style={{ borderRadius: 7 }}
                onPress={() => this.props.navigation.navigate('Home')}
              />
            </View>
          </ScrollView>
        </View>
      </View>
    );
  }
}
