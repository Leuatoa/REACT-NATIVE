import React, { Component } from 'react';
import {
  Button,
  Alert,
  Text,
  StyleSheet,
  View,
  Image,  
  TextInput,
  TouchableOpacity,
} from 'react-native';
    
import Style from '../Estilos.Style/Style';
import Imc from '../components/Imc'

export default class AvaliacaoFisicaScreen extends Component {
  static navigationOptions = {
    title: 'AVALIAÇÃO FISICA',
    headerStyle: {
      backgroundColor: '#000000',
    },
    headerTintColor: '#ffff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };



  render() {
    return (
      <View style={Style.background}>
        <View style={Style.container}>
        < Imc />
        </View>
      </View>
    );
  }
}

